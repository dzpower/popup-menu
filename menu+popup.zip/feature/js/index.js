const methods = {
    openPopup: () => {
        const el = document.querySelector('.overlay')
        el.classList.add('visible')
    },
    closePopup: () => {
        const el = document.querySelector('.overlay')
        el.classList.remove('visible')
    },
    toggleMenu: () => {
        const el = document.querySelector('.nav-list')
        const arr = JSON.parse(JSON.stringify(el.classList))
        console.log()
        if (Object.keys(arr).length === 1) {
            elements.btnMenu.classList.add('btn-active')
            el.classList.add('modile-show')
        } else {
            elements.btnMenu.classList.remove('btn-active')
            el.classList.remove('modile-show')
        }
    }
}

const elements = {
    btn: document.querySelector('.popup-opener'),
    btnClose: document.querySelectorAll('.popup-closer'),
    btnMenu: document.querySelector('.btn-menu'),
    links: document.querySelectorAll('.nav-list a')
}

document.addEventListener("DOMContentLoaded", function () {
    elements.btn.addEventListener('click', function (){
        methods.openPopup()
    })
    elements.btnClose.forEach(a => {
        a.addEventListener('click', function (){
            methods.closePopup()
        })
    })
    elements.links.forEach(a => {
        a.addEventListener('click', function (e){
            e.preventDefault()
            methods.toggleMenu()
        })
    })
    elements.btnMenu.addEventListener('click',  function (){
        methods.toggleMenu()
    })

});
